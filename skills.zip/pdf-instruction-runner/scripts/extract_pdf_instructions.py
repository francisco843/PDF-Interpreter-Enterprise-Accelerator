#!/usr/bin/env python3
"""Extract candidate instructions from PDF files."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

CODE_BLOCK_RE = re.compile(
    r"```(?:sh|bash|zsh|shell|console)?\s*\n(.*?)```",
    re.IGNORECASE | re.DOTALL,
)
PROMPT_LINE_RE = re.compile(r"^\s*[$%]\s+(.+?)\s*$")
PREFIX_RE = re.compile(r"^\s*(?:COMMAND|RUN|EXECUTE)\s*:\s*(.+?)\s*$", re.IGNORECASE)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract shell command candidates and plain-language instructions from PDFs."
    )
    parser.add_argument("paths", nargs="+", help="PDF files or directories to scan recursively")
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of a text report",
    )
    return parser.parse_args()


def collect_pdfs(raw_paths: list[str]) -> list[Path]:
    pdfs: set[Path] = set()
    for raw_path in raw_paths:
        path = Path(raw_path).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {path}")
        if path.is_file():
            if path.suffix.lower() == ".pdf":
                pdfs.add(path.resolve())
            continue
        for pdf in path.rglob("*.pdf"):
            if pdf.is_file():
                pdfs.add(pdf.resolve())
    return sorted(pdfs)


def extract_text_with_pypdf(pdf_path: Path) -> tuple[str, int]:
    errors: list[str] = []
    for module_name in ("pypdf", "PyPDF2"):
        try:
            module = __import__(module_name)
            reader = module.PdfReader(str(pdf_path))
            pages = []
            for page in reader.pages:
                pages.append(page.extract_text() or "")
            return "\n\n".join(pages), len(reader.pages)
        except Exception as exc:  # pragma: no cover - fallback path
            errors.append(f"{module_name}: {exc}")
    raise RuntimeError("; ".join(errors))


def extract_text_with_pdftotext(pdf_path: Path) -> tuple[str, int]:
    pdftotext = shutil.which("pdftotext")
    pdfinfo = shutil.which("pdfinfo")
    if not pdftotext:
        raise RuntimeError("pdftotext is not available")
    result = subprocess.run(
        [pdftotext, str(pdf_path), "-"],
        capture_output=True,
        text=True,
        check=True,
    )
    page_count = 0
    if pdfinfo:
        info = subprocess.run(
            [pdfinfo, str(pdf_path)],
            capture_output=True,
            text=True,
            check=False,
        )
        for line in info.stdout.splitlines():
            if line.startswith("Pages:"):
                try:
                    page_count = int(line.split(":", 1)[1].strip())
                except ValueError:
                    page_count = 0
                break
    return result.stdout, page_count


def extract_text(pdf_path: Path) -> tuple[str, int, str]:
    try:
        text, pages = extract_text_with_pypdf(pdf_path)
        return text, pages, "pypdf"
    except Exception as pypdf_error:
        try:
            text, pages = extract_text_with_pdftotext(pdf_path)
            return text, pages, "pdftotext"
        except Exception as pdftotext_error:
            raise RuntimeError(
                "Could not extract text from PDF. Install `pypdf` or `PyPDF2`, or install Poppler "
                "so `pdftotext` is available. "
                f"pypdf error: {pypdf_error}; pdftotext error: {pdftotext_error}"
            ) from pdftotext_error


def split_plain_instructions(text: str) -> list[str]:
    blocks = []
    for chunk in re.split(r"\n\s*\n", text):
        cleaned = " ".join(chunk.split())
        if not cleaned:
            continue
        if CODE_BLOCK_RE.search(chunk):
            continue
        if PROMPT_LINE_RE.match(cleaned) or PREFIX_RE.match(cleaned):
            continue
        blocks.append(cleaned)
    return blocks


def extract_command_candidates(text: str) -> list[str]:
    commands: list[str] = []

    for block in CODE_BLOCK_RE.findall(text):
        for line in block.splitlines():
            stripped = line.strip()
            if stripped:
                commands.append(stripped)

    for line in text.splitlines():
        prompt_match = PROMPT_LINE_RE.match(line)
        if prompt_match:
            commands.append(prompt_match.group(1).strip())
            continue
        prefix_match = PREFIX_RE.match(line)
        if prefix_match:
            commands.append(prefix_match.group(1).strip())

    deduped = []
    seen = set()
    for command in commands:
        if command not in seen:
            deduped.append(command)
            seen.add(command)
    return deduped


def build_record(pdf_path: Path) -> dict[str, object]:
    text, page_count, extractor = extract_text(pdf_path)
    commands = extract_command_candidates(text)
    plain_instructions = split_plain_instructions(text)
    preview = text[:1000].strip()
    return {
        "path": str(pdf_path),
        "pages": page_count,
        "extractor": extractor,
        "commands": commands,
        "plain_instructions": plain_instructions[:25],
        "preview": preview,
    }


def render_text_report(records: list[dict[str, object]]) -> str:
    lines = []
    for record in records:
        lines.append(f"PDF: {record['path']}")
        lines.append(f"Pages: {record['pages']} | Extractor: {record['extractor']}")
        commands = record["commands"]
        if commands:
            lines.append("Command candidates:")
            for command in commands:
                lines.append(f"  - {command}")
        else:
            lines.append("Command candidates: none found")
        instructions = record["plain_instructions"]
        if instructions:
            lines.append("Plain-language instructions:")
            for instruction in instructions[:10]:
                lines.append(f"  - {instruction}")
        else:
            lines.append("Plain-language instructions: none found")
        preview = record["preview"]
        lines.append("Preview:")
        lines.append(preview if preview else "[no text extracted]")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    args = parse_args()
    try:
        pdfs = collect_pdfs(args.paths)
        if not pdfs:
            raise FileNotFoundError("No PDF files found in the provided paths")
        records = [build_record(pdf_path) for pdf_path in pdfs]
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps({"pdfs": records}, indent=2))
    else:
        print(render_text_report(records), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
