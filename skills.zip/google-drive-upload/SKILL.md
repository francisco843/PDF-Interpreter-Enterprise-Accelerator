---
name: google-drive-upload
description: Upload local files or entire local folders to Google Drive, regardless of file type, including uploads to the user's own Drive account, another signed-in Google account, accessible shared folders, or shared/public folder links that accept uploads. Use when a request involves sending one or more files, mixed file types, directory trees, project folders, archives, media, or documents into Drive, choosing between Google accounts, targeting a specific Drive folder URL, or placing content into a shared/public destination where write access depends on the browser session.
---

# Google Drive Upload

## Overview

Upload local files or entire folders into Google Drive with the least-fragile path available.
Support arbitrary file types, mixed batches, and directory uploads. Use Google Drive connector tools for discovery and validation when possible, but use Atlas browser automation for the actual upload because the available Google Drive connector is read-only.

## Workflow

1. Confirm the upload inputs:
- Source files or folders to upload
- Whether the upload includes a whole folder tree or a flat set of files
- Destination account or folder
- Whether replacing an existing file is allowed
- Whether the destination should be verified before uploading

2. Check local file access before browsing:
- If the requested files are already inside the writable workspace, use them directly.
- If the files are elsewhere on disk, request directory access first.
- If the files do not exist yet, stop and ask for the correct path or files.
- If the user asked for an entire folder, pass the folder path itself when Atlas can upload folders directly; otherwise pass the folder contents and state that directory structure should be preserved when possible.

3. Use Google Drive tools first when they can reduce ambiguity:
- Use `google_drive_get_profile` to confirm the currently connected Google account.
- Use `google_drive_list_drives`, `google_drive_search`, `google_drive_list_folder`, or `google_drive_get_file_metadata` to validate a destination the connector can see.
- Treat these tools as discovery only. Do not assume they can upload, move, or create files.

4. Use Atlas for the actual upload:
- Delegate to Atlas whenever the task requires opening Google Drive, switching Google accounts, uploading files, uploading folders, preserving folder hierarchy, or interacting with a shared/public upload destination.
- Provide a focused browsing prompt with the files or folders to upload, the exact destination URL when available, the target Google account if the user specified one, whether the upload is a folder upload or file upload, the duplicate-file behavior, and the expected confirmation.
- Pass only the minimum required `filePaths`.
- When the destination is a public or shared link, instruct Atlas to verify whether upload permission exists before attempting the upload.
- When the content includes many file types, do not filter by extension unless the user explicitly asks for filtering.

5. Report the outcome clearly:
- Confirm which files were uploaded.
- Confirm whether any folders were uploaded as folders or flattened into separate files.
- State the destination folder or account used.
- Note any file that failed and why.
- Include the resulting Drive folder or file link when available.

## Decision Rules

- Prefer the Google Drive connector when the user only needs destination discovery, account verification, or folder inspection.
- Prefer Atlas as soon as any write action is required.
- If the user gives a Google Drive folder URL, validate it with the connector when possible, then upload through Atlas.
- If the user wants another Google account, name the target account clearly in the browsing prompt so Atlas can switch if needed.
- If the user references a public shared folder, do not assume anonymous upload is allowed. Inspect the page or Drive folder first and let Atlas determine whether sign-in or permissions are required.
- If the user asks to upload a whole folder, prefer sending the folder itself to Atlas instead of zipping it unless the destination UI rejects folder uploads.
- If Atlas cannot upload a folder directly, fall back to uploading the folder contents or creating an archive only if the user agrees.
- Treat all file extensions as allowed by default; the limiting factor is Drive or the destination page, not this skill.

## Clarifications To Ask

Ask only what is required to avoid a bad upload:
- Which files or folders should be uploaded?
- Where should they go: a folder URL, folder name, or a specific Google account?
- If a file with the same name already exists, should it be replaced, skipped, or duplicated?
- If the request is for a folder, should the folder structure be preserved exactly if Drive accepts it?

Skip questions when the request already supplies this information.

## Example Triggers

- "Sube este PDF a mi Google Drive."
- "Carga estas fotos a la carpeta compartida que te pasé."
- "Pon este archivo en mi cuenta personal de Gmail, no en la del trabajo."
- "Abre este enlace de carpeta y sube ahí los documentos."
- "Sube toda esta carpeta del proyecto a Drive."
- "Carga estos archivos, aunque sean de tipos distintos, en este enlace público."
- "Usa mi cuenta personal y sube esta carpeta completa manteniendo la estructura."

## Constraints

- Do not promise upload support through the Google Drive connector alone; it is read-only in this environment.
- Do not browse if the task is only to inspect Drive contents or identify a destination.
- Do not include full local file paths inside the Atlas prompt; pass them through `filePaths`.
- Do not claim every public Drive link is writable; Atlas must verify that the page actually permits uploads.
